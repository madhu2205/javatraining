package com.example.demojoin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemojoinApplicationTests {

	@Test
	void contextLoads() {
	}

}
