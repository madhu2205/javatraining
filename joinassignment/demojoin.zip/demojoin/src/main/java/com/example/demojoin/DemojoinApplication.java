package com.example.demojoin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemojoinApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemojoinApplication.class, args);
	}

}
