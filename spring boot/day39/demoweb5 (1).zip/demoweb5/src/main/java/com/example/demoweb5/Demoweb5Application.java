package com.example.demoweb5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demoweb5Application {

	public static void main(String[] args) {
		SpringApplication.run(Demoweb5Application.class, args);
	}

}
