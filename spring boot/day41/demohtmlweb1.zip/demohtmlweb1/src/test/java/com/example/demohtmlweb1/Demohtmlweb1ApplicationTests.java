package com.example.demohtmlweb1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demohtmlweb1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
