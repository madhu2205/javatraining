package com.example.demohtmlweb1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demohtmlweb1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demohtmlweb1Application.class, args);
	}

}
