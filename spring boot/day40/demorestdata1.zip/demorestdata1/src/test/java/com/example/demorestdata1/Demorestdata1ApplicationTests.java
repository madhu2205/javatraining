package com.example.demorestdata1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demorestdata1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
