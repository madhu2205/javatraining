package com.example.demoweb4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demoweb4Application {

	public static void main(String[] args) {
		SpringApplication.run(Demoweb4Application.class, args);
	}

}
