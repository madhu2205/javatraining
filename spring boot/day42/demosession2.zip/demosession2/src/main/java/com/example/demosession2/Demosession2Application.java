package com.example.demosession2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demosession2Application {

	public static void main(String[] args) {
		SpringApplication.run(Demosession2Application.class, args);
	}

}
