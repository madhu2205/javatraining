package com.example.demoonlineshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoonlineshoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoonlineshoppingApplication.class, args);
	}

}
