package com.example.demoonlineshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoonlineshoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
