package com.example.demoweb3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoweb3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
